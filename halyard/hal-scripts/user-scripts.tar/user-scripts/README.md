Please place any userscripts to be placed on the halyard vm in this directory. 
If you are reading this on the halyard vm, any userscripts you've placed in the user-scripts directory are located in this directory.
